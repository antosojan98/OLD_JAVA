/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class Lab4Q4 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    double amount= 0;
    
    
    do{
    System.out.println("Please enter the amount of money spent on groceries: ");
    amount=sc.nextDouble();
    }while(amount<=0);
    
    if(amount>500){
    
    System.out.println("Congratulations! Your total bill is: "+(amount*0.9));
      
    }else if(amount >=250 && amount <=500){
     
    System.out.println("Congratulations!Your total bill is: "+(amount*0.95));
      
    }else if(amount<250){
    
      System.out.println("Congratulations! YYour total bill is: "+(amount*0.98));
      
    }
    
    
    
  }
  
  /* ADD YOUR CODE HERE */
  
}

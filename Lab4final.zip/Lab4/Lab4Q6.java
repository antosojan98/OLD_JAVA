/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class Lab4Q6 {
  
  
  public static void main(String[] args) { 
    
         Scanner sc=new Scanner(System.in);
         double sum=0;
         int value;
         int counter=0;
         double average=0;
         int tencounter=0;
         int maximum=0;
         int oddcounter=0;
         
         
         do{
         System.out.println("Please enter another number or 0 if you wish to stop: ");
           value=sc.nextInt();
          
           
           if(value!=0){
             sum=sum+value;
             counter++;
           
             average=sum/counter;
           
             if(value%2==1)
               oddcounter++;
             if(value>maximum)
               maximum=value;
             if(value==10)
               tencounter++;
               
           }
           
            System.out.println("The sum of the input values is "+sum);
            System.out.println("The number of inputs is "+counter);
            System.out.println("The average of the input values is "+average);
            System.out.println("The number of odd values input is "+oddcounter);
            System.out.println("The value 10 was input  times  "+tencounter);
            System.out.println("The maximum value entered was "+maximum);
         }while(value !=0);
    
  }
  
  /* ADD YOUR CODE HERE */
  
}

/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class Lab4Q5 {
  
  
  public static void main(String[] args) { 
  
     Scanner sc=new Scanner(System.in);

     int text, voice, data;
  
     
        System.out.println("Please enter a maximum amount of voice minutes per month: ");
        voice=sc.nextInt();
        System.out.println("Please enter a maximum amount of text messages per month: ");
        text=sc.nextInt();
        System.out.println("Please enter a maximum amount data (in GB) per month: ");
        data=sc.nextInt();
       
        // Plan A
        if(voice<500&&data==0&&text==0){
        
           System.out.println("Plan A is your best choice, for only 49$ per month ");
        
           //Plan B
        }else if(voice<500&&data==0){
          
          System.out.println("Plan B is your best choice, for only 55$ per month ");
        //Plan C
        }else if(voice>=500&&data==0&&text<100){
          
          System.out.println("Plan C is your best choice, for only 61$ per month ");
          
          //Plan D
        }else if( voice>=500&&data==0&&text>=100){
        
               System.out.println("Plan D is your best choice, for only 70$ per month ");
        //Plan E
        }else if(data>0&&data<2){
          
         System.out.println("Plan E is your best choice, for only 79$ per month ");
        //Plan F
        }else if(data>=2){
        
           System.out.println("Plan F is your best choice, for only 87$ per month ");
          
        }
        
        /* Plan A A customer who needs fewer than 500 minutes of talk and no
text or data should accept Plan A at $49 per month. 

A customer who needs fewer than 500 minutes of talk and any text messages should accept Plan B at $55 per 
month.

A customer who needs 500 or more minutes of talk and no data should
accept either plan C for up to 100 text messages at $61 per month or Plan D for
100 text messages or more at $70 per month.

A customer who needs any data should accept Plan E for up to 2 gigabytes at $79 or Plan F for 2 gigabytes or
more at $87. */
        
        
        
        
        
  }
  
  
  
  /* ADD YOUR CODE HERE */
  
}

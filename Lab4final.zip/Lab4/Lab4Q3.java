/**
 * Auto Generated Java Class.
 */

import java.util.*;

public class Lab4Q3 {
  
  
  public static void main(String[] args) { 
    
    
    Scanner sc=new Scanner(System.in);
    Scanner sc2=new Scanner(System.in);
    double salary;
    
    System.out.println("please enter your name: ");
    String name=sc.nextLine();
    
    System.out.println("please enter your hourly wage: ");
    double wage=sc2.nextDouble();
   
    System.out.println("please enter the amount of hours you worked: ");
    double hours=sc2.nextDouble();
    
    if (hours > 40){
    
    hours=hours-40;  
    salary=wage*40;
    salary=salary+(wage*1.5*hours);
   
    System.out.println("paycheck for "+name+" :");
    System.out.println("worked a total amount of "+hours+" hours.");
    System.out.println("at a wage of "+wage+" dollars per hour.");
    System.out.println("you earned a total of "+salary+" dollars.");
    
      
    }else {
    
    salary=wage*hours;

    System.out.println("paycheck for "+name+" :");
    System.out.println("worked a total amount of "+hours+" hours.");
    System.out.println("at a wage of "+wage+" dollars per hour.");
    System.out.println("you earned a total of "+salary+" dollars.");
      
    
    }
    
    
    
    
    
  }
  
  /* ADD YOUR CODE HERE */
  
}

/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class Lab4Q2 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter a String.");     
    String st1=sc.nextLine();
    
    System.out.println("Please enter a Character.");
    String st2=sc.nextLine();
    
    char ch = st1.charAt(0);
    
    
    int counter =0;
    int charcounter =0;
    
    
    while (counter < st1.length()){
      
      if (ch == st1.charAt(counter)){
      charcounter++;
      }
           
      counter++;
    }
       
       
       System.out.println("There are "+charcounter+" "+ch);
      
  }
  
  /* ADD YOUR CODE HERE */
  
}

/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class Lab4Q1 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    System.out.println("Please enter a name: ");
    String name = sc.nextLine();
    String[] aname = new String[name.length()];
    int counter=0;
   
    
    while(counter < name.length()){
    
      aname[counter]=name.substring((name.length()-counter-1), (name.length()-counter));
      counter++; 
        
    }
    
        
    System.out.print("Name reversed: ");
    counter = 0;
    
    while(counter < name.length())
    {
      System.out.print(aname[counter]);
    counter++;
    }
   
    
    
    
  }
  
  /* ADD YOUR CODE HERE */
  
}
